---

---

# Source Code Submissions 
We welcome your contributions and look forward to collaborating with you. We can only accept source code repository 
submissions from users who have signed and returned the Oracle 
Contributor Agreement. You will find details and the agreement to sign at this OTN web page: 
[Oracle Contributor Agreement](http://www.oracle.com/technetwork/community/oca-486395.html). 

# Other Contributions
For all project Submissions other than source code repository contributions, the following also applies: Oracle does 
not claim ownership of Your Submissions. However, in order to fulfill 
the purposes of this project, You must give Oracle and all Users 
the right to post, access, discuss, use, publish, disseminate, and refine 
Your Submissions. 

In legalese: *You hereby grant to Oracle and all 
Users a royalty-free, perpetual, irrevocable, worldwide, non-exclusive, 
and fully sub-licensable right and license, under Your intellectual 
property rights, to reproduce, modify, adapt, publish, translate, create 
derivative works from, distribute, perform, display, and use Your 
Submissions (in whole or part) and to incorporate or implement them in 
other works in any form, media, or technology now known or later 
developed, all subject to the obligation to retain any copyright notices 
included in Your Submissions. All Users, Oracle, and their 
sublicensees are responsible for any modifications they make to the 
Submissions of others.*

Copyright &copy; 2017 Oracle and/or its affiliates. All rights reserved.
